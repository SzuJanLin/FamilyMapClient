package responses;

/**
 * response body for load function
 */
public class LoadResponse
{
    private String message;
    public LoadResponse(){}

    public LoadResponse(String message) {
        this.message = message;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}
