package responses;

/**
 * response body for clear function;
 */
public class ClearResponse
{
    private String message;

    public  ClearResponse(){}
    public ClearResponse(String message) {
        this.message = message;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}
