package database;


import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import model.Person;

/**
 * the class to handle persons
 */
public class PersonDAO extends DAO
{

    /**
     * initialize the database
     * @throws Exception
     */
    public PersonDAO() throws Exception
    {
        try
        {
            connect();
            createTable();
            disconnect(true);
        }
        catch (SQLException e)
        {
            e.printStackTrace();
        }
    }

    /**
     * create a table for person Dao
     * @throws Exception
     */
    void createTable() throws Exception {
        String sql = "CREATE TABLE IF NOT EXISTS Person (\n" +
                " personId text PRIMARY KEY,\n" +
                " descendant text,\n" +
                " firstName text NOT NULL,\n"+
                " lastName text NOT NULL,\n"+
                " gender text NOT NULL,\n"+
                " father text,\n" +
                " mother text,\n" +
                " spouse text\n" +");";

        try {
            Statement stmt = null;
            try {
                stmt = conn.createStatement();

                stmt.executeUpdate(sql);
            } finally {
                if (stmt != null) {
                    stmt.close();
                    //disconnect(true);
                    stmt = null;
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }


    /**
     * get a array of persons associated with the user
     * @param descendant
     * @return
     */
    public ArrayList<Person> getPeople(String descendant)
    {
        String sql = "SELECT firstName, lastName, personId, descendant,gender,father,mother,spouse FROM Person WHERE descendant = ?";
        Person output = new Person();
        ArrayList<Person> people = new ArrayList<>();

        try
        {
            connect();
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setString(1,descendant);
            ResultSet rs = pstmt.executeQuery();

            //input the data into model
            while(rs.next()){

                output.setFirstName(rs.getString(1));
                output.setLastName(rs.getString(2));
                output.setPersonID(rs.getString(3));
                output.setDescendant(rs.getString(4));
                output.setGender(rs.getString(5));
                output.setFather(rs.getString(6));
                output.setMother(rs.getString(7));
                output.setSpouse(rs.getString(8));
                people.add(output);
                output = new Person();
            }




            disconnect(true);
            rs.close();
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }


        return people;
    }


    /**
     * pass in a person's id and the username to get  a specific person
     * @param personId
     * @return
     */
  public Person getPerson(String personId)
{
    String sql = "SELECT firstName, lastName, personId, descendant,gender,father,mother,spouse FROM Person WHERE personId = ?";
    Person output = new Person();

    try
    {
        connect();
        PreparedStatement pstmt = conn.prepareStatement(sql);
        pstmt.setString(1,personId);
        ResultSet rs = pstmt.executeQuery();

        //input the data into model
        while(rs.next()){

            output.setFirstName(rs.getString(1));
            output.setLastName(rs.getString(2));
            output.setPersonID(rs.getString(3));
            output.setDescendant(rs.getString(4));
            output.setGender(rs.getString(5));
            output.setFather(rs.getString(6));
            output.setMother(rs.getString(7));
            output.setSpouse(rs.getString(8));
        }




        disconnect(true);
        rs.close();
    }
    catch (Exception e)
    {
        e.printStackTrace();
    }


    return output;
}

    /**
     * create a person's id and store it
     * @param person
     */
    public void addPerson(Person person)
    {
        String sql = "INSERT INTO Person(personId,descendant,firstName,lastName,"+
                "gender,father,mother,spouse) VALUES(?,?,?,?,?,?,?,?)";
        PreparedStatement pstmt = null;
        try
        {
            connect();
            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1,person.getPersonID());
            pstmt.setString(2,person.getDescendant());
            pstmt.setString(3,person.getFirstName());
            pstmt.setString(4,person.getLastName());
            pstmt.setString(5,person.getGender());
            pstmt.setString(6,person.getFather());
            pstmt.setString(7,person.getMother());
            pstmt.setString(8,person.getSpouse());
            pstmt.executeUpdate();
            disconnect(true);
        }
        catch (Exception e)
        {
            e.printStackTrace();

        }
        finally {
            try {
                pstmt.close();

            }
            catch (Exception e)
            {
                e.printStackTrace();
            }
        }



    }

    /**
     * Clear the current DOA for data testing
     */
   public void clear()
{
    String sql = "DROP TABLE Person";
    PreparedStatement pstmt = null;
    try
    {
        this.connect();
        pstmt = conn.prepareStatement(sql);
        pstmt.executeUpdate();


        disconnect(true);
    }
    catch (Exception e)
    {

    }
    finally {
        try {
            pstmt.close();

        } catch (Exception e) {

        }
    }

}

    /**
     * pass in a personId to delete a specific person.
     * @param descendant
     */
   public void delete(String descendant )
{
    String sql = "DELETE FROM Person Where descendant = ?";
    try
    {
        this.connect();
        PreparedStatement pstmt = conn.prepareStatement(sql);
        pstmt.setString(1,descendant);
        pstmt.executeUpdate();


        disconnect(true);
    }
    catch (Exception e)
    {
        System.out.println(e.getMessage());

    }
}




}
