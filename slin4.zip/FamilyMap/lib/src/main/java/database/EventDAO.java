package database;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import model.Event;

/**
 * the class to handle events
 */
public class EventDAO extends DAO{

    /**
     * initialize the database
     * @throws Exception
     */
   public EventDAO() throws Exception
    {
        try
        {
            connect();
            createTable();
            disconnect(true);
        }
        catch (SQLException e)
        {
            e.printStackTrace();
        }
    }

    /**
     * create the table it doesn't exit
     * @throws Exception
     */
    void createTable() throws Exception
    {

        String sql = "CREATE TABLE IF NOT EXISTS Event (\n" +
                " event_id text PRIMARY KEY,\n" +
                " descendant text NOT NULL,\n" +
                " person_id text NOT NULL,\n" +
                " latitude text NOT NULL,\n" +
                " longitude text NOT NULL,\n" +
                " country text NOT NULL,\n" +
                " city text NOT NULL,\n" +
                " eventType text NOT NULL,\n" +
                " year INTEGER NOT NULL\n" +");";


        try {
            Statement stmt = null;
            try {
                stmt = conn.createStatement();

                stmt.executeUpdate(sql);
            }
            finally {
                if (stmt != null) {
                    stmt.close();
                    //disconnect(true);
                    stmt = null;
                }
            }
        }
        catch (SQLException e) {
            e.printStackTrace();
        }


    }


    /**
     *  get the event from the request form
     * @param event_id
     * @return
     */
    public Event getEvent(String event_id)
    {
        String sql = "SELECT event_id, descendant, person_id" +
                ",latitude, longitude, country, city, eventType, year" +
                " FROM Event WHERE event_id = ?";

        Event output = new Event();

        try
        {
            connect();
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setString(1,event_id);
            ResultSet rs = pstmt.executeQuery();

            while(rs.next()){
                output.setEventID(rs.getString(1));
                output.setDescendant(rs.getString(2));
                output.setPersonID(rs.getString(3));
                output.setLatitude(rs.getString(4));
                output.setLongitude(rs.getString(5));
                output.setCountry(rs.getString(6));
                output.setCity(rs.getString(7));
                output.setEventType(rs.getString(8));
                output.setYear(rs.getInt(9));
            }

            //disconnect if it's true
            disconnect(true);
            rs.close();
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }

        return output;
    }

    /**
     * get a array of Events related to username
     * @param username
     * @return
     */
    public ArrayList<Event> getEvents(String username)
    { String sql = "SELECT event_id, descendant, person_id" +
            ",latitude, longitude, country, city, eventType, year" +
            " FROM Event WHERE descendant = ?";
            Event output = new Event();
        ArrayList<Event> events = new ArrayList<>();

        try
        {
            connect();
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setString(1,username);
            ResultSet rs = pstmt.executeQuery();

            //input the data into model
            while(rs.next()){

                output.setEventID(rs.getString(1));
                output.setDescendant(rs.getString(2));
                output.setPersonID(rs.getString(3));
                output.setLatitude(rs.getString(4));
                output.setLongitude(rs.getString(5));
                output.setCountry(rs.getString(6));
                output.setCity(rs.getString(7));
                output.setEventType(rs.getString(8));
                output.setYear(rs.getInt(9));
                events.add(output);
                output = new Event();
            }
            disconnect(true);
            rs.close();
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }

        return events;
    }


    /**
     * add an event into the event Dao
     * @param event
     */
    public void addEvent(Event event)
    {
        String sql = "INSERT INTO Event(event_id,descendant,person_id,latitude,"+
                "longitude,country,city,eventType,year) VALUES(?,?,?,?,?,?,?,?,?)";

        PreparedStatement pstmt = null;
        try
        {
            connect();
            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1,event.getEventID());
            pstmt.setString(2,event.getDescendant());
            pstmt.setString(3,event.getPersonID());
            pstmt.setString(4,event.getLatitude());
            pstmt.setString(5,event.getLongitude());
            pstmt.setString(6,event.getCountry());
            pstmt.setString(7,event.getCity());
            pstmt.setString(8,event.getEventType());
            pstmt.setInt(9,event.getYear());
            pstmt.executeUpdate();
            disconnect(true);
        }
        catch (Exception e)
        {
            e.printStackTrace();

        }
        finally {
            try {
                pstmt.close();

            }
            catch (Exception e)
            {
                e.printStackTrace();
            }
        }



    }


    /**
     * Clear the DAO for  testing
     */
    public void clear()
    {
        String sql = "DROP TABLE Event";
        PreparedStatement pstmt = null;
        try // connect to the database
        {
            this.connect();
            pstmt = conn.prepareStatement(sql);
            pstmt.executeUpdate();
            disconnect(true);
        }
        catch (Exception e)
        {

        }
        finally {
            try {
                pstmt.close();

            } catch (Exception e) {

            }
        }
    }

    /**
     * delete a specific event for testing
     * @param descendant
     */
    public void delete(String descendant )
    {
        String sql = "DELETE FROM Event Where descendant = ?";
        try//connect to the database
        {
            this.connect();
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setString(1,descendant);
            pstmt.executeUpdate();
            disconnect(true);
        }
        catch (Exception e)
        {
            System.out.println(e.getMessage());

        }
    }
}
