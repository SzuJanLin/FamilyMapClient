package database;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import model.AuthToken;
import model.User;
import model.User;

/**
 * the class to handle authToken and the usernames
 */
public class AuthTokenDAO extends DAO
{
    /**
     * initialize the database
     * @throws Exception
     */
   public AuthTokenDAO() throws Exception
    {
        try
        {
            connect();
            createTable();
            disconnect(true);
        }
        catch (SQLException e)
        {
            e.printStackTrace();
        }
    }


    /**
     * create the table it doesn't exit
     * @throws Exception
     */
    void createTable() throws Exception
    {

        String sql = "CREATE TABLE IF NOT EXISTS AuthToken (\n" +
                " authToken text PRIMARY KEY,\n" +
                " username text NOT NULL\n" + ");";

        //create statement
        try {
            Statement stmt = null;
            try {
                stmt = conn.createStatement();

                stmt.executeUpdate(sql);
            }
            finally {
                if (stmt != null) {
                    stmt.close();
                    //disconnect(true);
                    stmt = null;
                }
            }
        }
        catch (SQLException e) {
            e.printStackTrace();
        }
    }








    /**
     * find  a current token
     * @param authToken
     * @return
     */
    public String getUsername(String authToken)
    {
        String sql = "SELECT username" +
                " FROM AuthToken WHERE authToken = ?";

        String output = null;
        try
        {
            connect();
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setString(1,authToken);
            ResultSet rs = pstmt.executeQuery();

            while(rs.next()){
                output = rs.getString(1);

            }
            disconnect(true);
            rs.close();
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
        return output;


    }


    /**
     * create  an AuthToken for  the user
     * @param username
     */
    public void addAuthToken(AuthToken username)
    {
        String sql = "INSERT INTO AuthToken(authToken,username) VALUES(?,?)";
        PreparedStatement pstmt = null;
        try
        {
            connect();
            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1,username.getAuthToken());
            pstmt.setString(2,username.getUserName());
            pstmt.executeUpdate();
            disconnect(true);
        }
        catch (Exception e)
        {
            e.printStackTrace();

        }
        finally {
            try {
                pstmt.close();

            }
            catch (Exception e)
            {
            e.printStackTrace();
            }
        }

    }


    /**
     * Clear the DAO
     * */
    public void clear()
    {
        String sql = "DROP TABLE AuthToken";
        PreparedStatement pstmt = null;
        try
        {
            this.connect();
            pstmt = conn.prepareStatement(sql);
            pstmt.executeUpdate();


            disconnect(true);
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
        finally {
            try {
                pstmt.close();

            } catch (Exception e)
            {
                e.printStackTrace();
            }
        }
    }

    /**
     * delete a specific event for testing
     * @param AuthToken
     */
    void delete(String AuthToken )
    {
        String sql = "DELETE FROM Event Where AuthToken = ?";
        try
        {
            this.connect();
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setString(1,AuthToken);
            pstmt.executeUpdate();


            disconnect(true);
        }
        catch (Exception e)
        {
            System.out.println(e.getMessage());

        }
    }


    /**
     * pass in the authToken and get the user's Login access.
     * @param username
     * @return
     */
    public String getAuthToken(String username)
    {
        String sql = "SELECT authToken" +
                " FROM AuthToken WHERE username = ?";

        String output = null;
        try
        {
            connect();
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setString(1,username);
            ResultSet rs = pstmt.executeQuery();

            while(rs.next()){
                output = rs.getString(1);

            }
            disconnect(true);
            rs.close();
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
        return output;
    }

}
