package database;

import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * parent class for all of the Daos, has the connect functions
 */
public class DAO
{

    //connect variable
    Connection conn;
    static {
        try {
            final String driver = "org.sqlite.JDBC";
            Class.forName(driver);
        }
        catch (ClassNotFoundException e)
        {
            e.printStackTrace();
        }
    }

    /**
     * open the connection for the database.
     */
    public void connect() throws Exception
    {
      try{
          final String CONNECTION_URL = "JDBC:sqlite:schema2.db";

          conn = DriverManager.getConnection(CONNECTION_URL);
          conn.setAutoCommit(false);
      }
      catch (Exception e)
      {
          System.out.println("openConnection failed");
          throw e;
      }

    }

    /**
     * if it's committed, then close the connection
     * @param commit
     * @throws Exception
     */
    public void disconnect(boolean commit) throws Exception
    {
        try
        {
            if(commit)
                conn.commit();
            else
                conn.rollback();
            conn.close();
            conn = null;
        }
        catch (SQLException e)
        {
            throw e;
        }
    }

}
