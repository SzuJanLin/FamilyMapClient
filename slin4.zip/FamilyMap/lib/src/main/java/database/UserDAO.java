package database;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import model.User;

/**
 * the class to handle users
 */
public class UserDAO extends DAO
{


    /**
     * initialize the database
     * @throws Exception
     */
    public UserDAO() throws Exception
    {
        try
        {
            connect();
            createTable();
            disconnect(true);
        }
        catch (SQLException e)
        {
            e.printStackTrace();
        }
    }


    /**
     * create the table it doesn't exit
     * @throws Exception
     */
    void createTable() throws Exception
    {

        String sql = "CREATE TABLE IF NOT EXISTS User (\n" +
                " username text PRIMARY KEY,\n" +
                " password text NOT NULL,\n" +
                " email text NOT NULL,\n" +
                " first_name text NOT NULL,\n" +
                " last_name text NOT NULL,\n" +
                " gender text NOT NULL,\n" +
                " personId text NOT NULL\n" + ");";


        try {
            Statement stmt = null;
            try {
                stmt = conn.createStatement();

                stmt.executeUpdate(sql);
            }
            finally {
                if (stmt != null) {
                    stmt.close();
                }
            }
        }
        catch (SQLException e) {
            e.printStackTrace();
        }


    }


    /**
     * pass in a LoginRequest and get the user's information
     * @param username
     * @return
     */
    public User getUser (String username)
    {
        String sql = "SELECT username, password, email" +
                ",first_name, last_name, gender, personId" +
                " FROM User WHERE username = ?";
        User output = null;

        try
        {
            connect();
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setString(1,username);
            ResultSet rs = pstmt.executeQuery();

            output = new User();
            //input the data into model
            while(rs.next()){
                output.setUserName(rs.getString(1));
                output.setPassword(rs.getString(2));
                output.setEmail(rs.getString(3));
                output.setFirstName(rs.getString(4));
                output.setLastName(rs.getString(5));
                output.setGender(rs.getString(6));
                output.setPersonID(rs.getString(7));
            }
            disconnect(true);
            rs.close();
        }
        catch (Exception e)
        {
            output = null;
            e.printStackTrace();
        }
        return output;
    }


    /**
     * addUser user to the database
     * @param user
     */
    public void addUser(User user)
    {

        String sql = "INSERT INTO User(username,password,email" +
                ",first_name, last_name, gender, personId) VALUES(?,?,?,?,?,?,?)";
        PreparedStatement pstmt = null;
        try
        {
            connect();
            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1,user.getUserName());
            pstmt.setString(2,user.getPassword());
            pstmt.setString(3,user.getEmail());
            pstmt.setString(4,user.getFirstName());
            pstmt.setString(5,user.getLastName());
            pstmt.setString(6,user.getGender());
            pstmt.setString(7,user.getPersonID());
            pstmt.executeUpdate();
            disconnect(true);
        }
        catch (Exception e)
        {
            e.printStackTrace();

        }
        finally {
            try {
                pstmt.close();

            }
            catch (Exception e)
            {
                e.printStackTrace();
            }
        }

    }




    /**
     * Clear the user dao for  testing purpose
     */
    public void clear()
    {
        String sql = "DROP TABLE User";
        PreparedStatement pstmt = null;
        try
        {
            this.connect();
            pstmt = conn.prepareStatement(sql);
            pstmt.executeUpdate();


            disconnect(true);
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
        finally {
            try {
                pstmt.close();

            } catch (Exception e) {

            }
        }
    }

    /**
     * delete a username from DAO for testing purpose
     * @param username
     */
    public void delete(String username)
    {

        String sql = "DELETE FROM User Where username = ?";
        try
        {
            this.connect();
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setString(1,username);
            pstmt.executeUpdate();

            disconnect(true);
        }
        catch (Exception e)
        {
            System.out.println(e.getMessage());

        }
    }
}
