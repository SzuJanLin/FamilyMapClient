package service;

import java.util.ArrayList;
import java.util.Random;
import java.util.UUID;

import database.EventDAO;
import database.PersonDAO;
import database.UserDAO;
import jsonTempClass.Location;
import jsonTempClass.Locations;
import jsonTempClass.Names;
import model.Event;
import model.Person;
import model.User;
import responses.FillResponse;

/**
 * add people and events into the database for a certain user
 */
public class Fill
{
    public Fill(){}

    int personCounter;
    int eventCounter;
    String username;
    int generation;
    Locations Locations;
    ArrayList<String> eventType;

    int eventyear = 1990; // the start off default year
    int timeGap = 30; // gap for the ancestors
    String thisUserId;
    String currentEvent;

    Names fnames;
    Names mnames;
    Names snames;

    /**
     * fill is the root recursion function and works as a initializer for the class.
     * It creates the data member for the user and then call create ancestor for the user
     * @param username
     * @param generation
     * @param Locations
     * @param fnames
     * @param mnames
     * @param snames
     * @return
     */
 public FillResponse fill(String username, int generation , Locations Locations,
                          Names fnames, Names mnames, Names snames)
 {
     this.username =username;
     this.Locations = Locations;
     this.fnames = fnames;
     this.mnames = mnames;
     this.snames =snames;
     this.generation =generation;
     personCounter = 1;
     eventCounter = 0;
     eventType = new ArrayList<>();
     eventType.add("birth");
     eventType.add("baptism");
     eventType.add("death");
    currentEvent = new String();



     String father_id = UUID.randomUUID().toString(); // this is for the father to create
     String mother_id = UUID.randomUUID().toString(); // mother to create
     FillResponse rp;
     try
     {
         boolean success = false;

         UserDAO userDAO = new UserDAO();
         PersonDAO personDAO = new PersonDAO();

         User user = userDAO.getUser(username);
         Person person = new Person(user.getPersonID(),username,user.getFirstName()
                 ,user.getLastName(),user.getGender(),father_id,mother_id,null);

         Random random = new Random();//random year for the user to set for event
         int gap = random.nextInt(5);

         thisUserId = user.getPersonID(); // make sure the UserId won't be set as death

         //fill two events for the user
         fillEvents(user.getPersonID(),2020+gap);
         fillEvents(user.getPersonID(),2020+gap);

         personDAO.addPerson(person);

         // create mom and dad
         fillRecursionMale(0,father_id,mother_id,eventyear);
         fillRecursionFemale(0,mother_id,father_id,eventyear);
         String message = "Successfully added " + personCounter + " persons and "
                 + eventCounter + " events to the database";
         rp = new FillResponse(message);

     }
     catch (Exception e)
     {
         String message = "Error";

         rp = new FillResponse(message);
         e.printStackTrace();
     }
     return rp;
 }

    /**
     * fill a male for the last person.
     * @param cur
     * @param person_id
     * @param spouse_id
     * @param year
     * @throws Exception
     */
    private void fillRecursionMale( int cur, String person_id, String spouse_id, int year) throws Exception
    {
        personCounter++;
        try {

            PersonDAO personDAO = new PersonDAO();

            String male = createMale();
            String surname =createSurname();

            Person temp = new Person(person_id,username,male,surname,"m"); // default person
            temp.setSpouse(spouse_id);

            // fill two events for the person
            fillEvents(person_id,year);
            year = fillEvents(person_id,year);


            if (cur < generation-1)
            {
                String father_id = UUID.randomUUID().toString(); //father to create
                String mother_id = UUID.randomUUID().toString(); // mother to create
                temp.setFather(father_id);
                temp.setMother(mother_id);

                cur++;
                fillRecursionMale(cur,father_id,mother_id, year);
                fillRecursionFemale(cur,mother_id,father_id,year);
            }
            personDAO.addPerson(temp);

        }
        catch (Exception e)
        {
            e.printStackTrace();
            throw  e;
        }


    }

    /**
     * same as fillRecursionMale but for females
     * @param cur
     * @param person_id
     * @param spouse_id
     * @param year
     * @throws Exception
     */
    private void fillRecursionFemale( int cur, String person_id, String spouse_id , int year) throws Exception
    {
        try {
            personCounter++;

            PersonDAO personDAO = new PersonDAO();
            String female = createFemale();
            String surname =createSurname();

            Person temp = new Person(person_id,username,female,surname,"f");
            temp.setSpouse(spouse_id);
            fillEvents(person_id,year);
            year =  fillEvents(person_id,year);


            if (cur < generation-1)
            {
                String father_id = UUID.randomUUID().toString();
                String mother_id = UUID.randomUUID().toString();
                temp.setFather(father_id);
                temp.setMother(mother_id);
                cur++;
                fillRecursionMale(cur,father_id,mother_id,year);
                fillRecursionFemale(cur,mother_id,father_id,year);
            }

            personDAO.addPerson(temp);
        }
        catch (Exception e)
        {
            e.printStackTrace();
            throw  e;
        }
    }

    /**
     * fill the event for a certain person Id, year is the appoximate year for the person's birth
     * @param person_id
     * @param year
     * @return
     * @throws Exception
     */
    private int fillEvents( String person_id, int year) throws Exception
    {
        eventCounter++;
        try
        {
            EventDAO eventDAO = new EventDAO();
            String event_id = UUID.randomUUID().toString();
            Location  tempL = createLocation();

            Random random = new Random();
            int sValue = random.nextInt(eventType.size());



            String type = eventType.get(sValue);
            while (currentEvent.equals(type))
            {
                sValue = random.nextInt(eventType.size());
                type = eventType.get(sValue);
            }
            currentEvent = type;

            int gap = random.nextInt(5);
            int difference  = gap+ timeGap;
            year = year - difference;
            int target = year; // have a 30+-5 difference


            if (thisUserId.equals(person_id))
            {
                type = "birth";
            }

            if (type.equals("death"))
            {
                int gap2 = random.nextInt(20);
                target = gap2 + year + 30; //have a nearly 30+_20 year of difference for death
            }
            else if (type.equals("baptism"))
            {
                int gap3 = random.nextInt(8); // eight years after birth
                target = gap3 + year;
            }




            Event temp = new Event(event_id,username,person_id,
                    tempL.getLatitude(),tempL.getLongitude(),
                    tempL.getCountry(),tempL.getCity(),type,target);

            eventDAO.addEvent(temp);
        }
        catch (Exception e)
        {
            e.printStackTrace();
            throw  e;
        }

        return year;
    }


    /**
     * randomly create a male name
     * @return
     */
 private String createMale( )
 {
     Random random = new Random();
     int mValue = random.nextInt(mnames.getData().size());
     String male = mnames.getData().get(mValue);
     return male;
 }

    /**
     * randomly create a surname
     * @return
     */
 private String createSurname()
 {
     Random random = new Random();
     int sValue = random.nextInt(snames.getData().size());
     String surname = snames.getData().get(sValue);
     return surname;
 }

    /**
     * randomly create a female name
     * @return
     */
    private String createFemale( )
    {
        Random random = new Random();
        int sValue = random.nextInt(fnames.getData().size());
        String fname = fnames.getData().get(sValue);
        return fname;
    }

    /**
     * randomly create a location
     * @return
     */
 private Location createLocation()
 {
     Random random = new Random();
     int lValue = random.nextInt(Locations.getData().size());
     Location tempLocation = Locations.getData().get(lValue);
     return tempLocation;
 }



}
