package service;


import java.util.UUID;

import database.AuthTokenDAO;
import database.UserDAO;
import model.AuthToken;
import model.User;
import requests.LoginRequest;
import responses.LoginResponse;

/**
 * login service
 */
public class LoginService
{
   public LoginService(){}
    /**
     * login for the user
     * @param rq
     * @return
     */
    public LoginResponse login(LoginRequest rq)
    {
        String username = rq.getUserName();
        String password = rq.getPassword();
        String authToken = null;
        String personID = null;
        LoginResponse response = new LoginResponse();

        try
        {
            //create authToken
            AuthTokenDAO authDao = new AuthTokenDAO();
            authToken = UUID.randomUUID().toString();
            AuthToken tempAuth = new AuthToken(authToken,username);
            authDao.addAuthToken(tempAuth);

            UserDAO uDao = new UserDAO();
            User temp = uDao.getUser(username);

            //check the password is valid
            if(password.equals(temp.getPassword()))
                personID = temp.getPersonID();
            else
            {
                response.setMessage("ERROR: wrong password");
                throw new Exception();
            }

            //context cannot be null
            if(authToken == null || username == null || personID == null)
            {
                response.setMessage("ERROR: context cannot be null");
                throw new Exception();
            }


          response = new LoginResponse(authToken,username,personID,"Successful");

        }
        catch (Exception e)
        {

            e.printStackTrace();
        }

        return  response;
    }
}
