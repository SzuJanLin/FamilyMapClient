package service;

import java.util.ArrayList;

import database.AuthTokenDAO;
import database.EventDAO;
import model.Event;
import requests.EventRequest;
import responses.EventResponse;

/**
 * event service
 */
public class EventService
{
   public EventService(){}

    /**
     * get a event
     * @param rq
     * @return
     */
    public EventResponse getEvent(EventRequest rq)
    {
        // get the info
        String authToken = rq.getAuthToken();
        String eventId = rq.getEvent_id();

        // response
        EventResponse response = new EventResponse();
        String username = null;

        try
        {
            AuthTokenDAO authDao = new AuthTokenDAO();
            EventDAO eDao = new EventDAO();
            username = authDao.getUsername(authToken);

            Event eModel = eDao.getEvent(eventId);

            if (!eModel.getDescendant().equals(username))
                // make sure the event belongs to the user
            {
                response.setMessage("ERROR: Not your ancestors event");
                throw new Exception();
            }

            if (eModel.hasNull())
                throw new Exception();


            response = new EventResponse(eModel.getEventID(),
                    eModel.getDescendant(),eModel.getPersonID(),
                    eModel.getLatitude(),eModel.getLongitude(),
                    eModel.getCountry(),eModel.getCity(),
                    eModel.getEventType(),eModel.getYear(),
                    "successful");

        }
        catch (Exception e)
        {

            e.printStackTrace();
        }

        return  response;
    }


    /**
     * return an array of the Event response objects
     * @param rq
     * @return
     */
    public ArrayList<EventResponse> getEvents(EventRequest rq)
    {

        String authToken = rq.getAuthToken();
        String eventId = rq.getEvent_id();
        ArrayList<EventResponse> responseArray = new ArrayList<>();
        ArrayList<Event>  eventArray = new ArrayList<>();

        EventResponse response = new EventResponse();
        String username = null;

        try
        {
            AuthTokenDAO authDao = new AuthTokenDAO();
            EventDAO eDao = new EventDAO();
            username = authDao.getUsername(authToken);

            eventArray = eDao.getEvents(username);

            for (int i =0 ; i < eventArray.size(); i++) {
                Event pModel = eventArray.get(i);
                if (pModel.hasNull())
                    throw new Exception();
                if (!pModel.getDescendant().equals(username))
                    // make sure the event belongs to the user
                {
                    throw new Exception();
                }


                response = new EventResponse(pModel.getEventID(),
                        pModel.getDescendant(),pModel.getPersonID(),
                        pModel.getLatitude(),pModel.getLongitude(),
                        pModel.getCountry(),pModel.getCity(),
                        pModel.getEventType(),pModel.getYear(),
                        "successful");
                responseArray.add(response);
                response = new EventResponse();
            }

        }
        catch (Exception e)
        {
            response.setMessage("ERROR");
            responseArray.add(response);
            e.printStackTrace();
        }

        return  responseArray;
    }






}
