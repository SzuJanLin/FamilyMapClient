package service;

import database.AuthTokenDAO;
import database.EventDAO;
import database.PersonDAO;
import database.UserDAO;
import responses.ClearResponse;

/**
 * Clear the database
 */
public class Clear
{
    public Clear(){}
    /**
     * Clear the database
     */
    public ClearResponse clear()
    {
        ClearResponse rp = new ClearResponse();
        //call all the daos and it's clear functions
        try {
            AuthTokenDAO authTokenDAO = new AuthTokenDAO();
            authTokenDAO.clear();
            EventDAO eventDAO = new EventDAO();
            eventDAO.clear();
            PersonDAO personDAO = new PersonDAO();
            personDAO.clear();
            UserDAO userDAO = new UserDAO();
            userDAO.clear();
            rp = new ClearResponse("successful");
        }
        catch (Exception e)
        {
            rp.setMessage("Error");
            e.printStackTrace();
        }


        return rp;
    }
}
