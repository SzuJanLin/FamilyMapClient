package service;

import java.util.ArrayList;

import database.AuthTokenDAO;
import database.EventDAO;
import database.PersonDAO;
import database.UserDAO;
import model.Event;
import model.Person;
import model.User;
import requests.LoadRequest;
import responses.EventResponse;
import responses.LoadResponse;
import responses.LoginResponse;
import responses.PersonResponse;

/**l
 * Load the user , persons and events.
 */
public class Load
{
    public Load(){}

    /**
     *  clear the data base and load data
     *  data is consist of three arrays
     * @param rq
     */
    public LoadResponse load(LoadRequest rq)
    {

        // get the arrays first
        ArrayList<User> users =rq.getUsers() ;
        ArrayList<Person> people = rq.getPersons();
        ArrayList<Event> events = rq.getEvents();

        LoadResponse rp = new LoadResponse();
        Clear clear = new Clear();
        clear.clear();
        try
        {
            UserDAO userDAO = new UserDAO();
            for (int i = 0; i < users.size(); i++)
            {
                User uTemp = users.get(i);

                if (uTemp.hasNull()) // assert there is no null
                    throw new Exception();

                userDAO.addUser(uTemp);
            }
            PersonDAO personDAO = new PersonDAO();
            for (int i = 0; i < people.size(); i++)
            {
                Person pTemp = people.get(i);
                if (pTemp.hasNull())// assert there is no null
                    throw new Exception();

                personDAO.addPerson(pTemp);
            }
            EventDAO eventDAO = new EventDAO();
            for (int i = 0 ; i< events.size(); i++)
            {
                Event eTemp = events.get(i);
                if (eTemp.hasNull())// assert there is no null
                    throw new Exception();
                eventDAO.addEvent(eTemp);
            }
            String message = "Successfully added " + users.size() + " users, "
                    + people.size() + " persons, and " + events.size() +
                    " events to the database.";
            rp.setMessage(message);
        }
        catch (Exception e)
        {
            rp.setMessage("ERROR");
            e.printStackTrace();
        }
    return rp;
    }

}
