package service;

import java.util.ArrayList;

import database.AuthTokenDAO;
import database.PersonDAO;
import model.Person;
import requests.PersonRequest;
import responses.PersonResponse;

/**
 * get the person Service
 */
public class PersonService
{
    public PersonService() {
    }

    /**
     * get the person
     * @param rq
     * @return
     */
    public PersonResponse getPerson(PersonRequest rq)
    {

        String authToken = rq.getAuthToken();
        String personID = rq.getPersonId();


        PersonResponse response = new PersonResponse();
        String username = null;

        try
        {
            AuthTokenDAO authDao = new AuthTokenDAO();
            PersonDAO pDao = new PersonDAO();

            username = authDao.getUsername(authToken);
            Person pModel = pDao.getPerson(personID);
            if (!pModel.getDescendant().equals(username))
            {
                response.setMessage("ERROR: Not your ancestor");
                throw new Exception();
            }

            if (pModel.hasNull())
                throw new Exception();


            response = new PersonResponse(pModel.getPersonID(),
                    pModel.getDescendant(),pModel.getFirstName(),
                    pModel.getLastName(),pModel.getGender(),
                    pModel.getFather(),pModel.getMother(),
                    pModel.getSpouse(),"successful");

        }
        catch (Exception e)
        {

            e.printStackTrace();
        }

        return  response;
    }

    /**
     * return an array of the Person response objects
     * @param rq
     * @return
     */
    public ArrayList<PersonResponse> getPeople(PersonRequest rq)
    {

        String authToken = rq.getAuthToken();
        String personID = rq.getPersonId();
        ArrayList<PersonResponse> responseArray = new ArrayList<>();
        ArrayList<Person>  personArray = new ArrayList<>();

        PersonResponse response = new PersonResponse();
        String username = null;

        try
        {
            AuthTokenDAO authDao = new AuthTokenDAO();
            PersonDAO pDao = new PersonDAO();
            username = authDao.getUsername(authToken);


            personArray = pDao.getPeople(username);

            for (int i =0 ; i < personArray.size(); i++) {
                Person pModel = personArray.get(i);

                if (!pModel.getDescendant().equals(username))
                {
                    throw new Exception();
                }

                if (pModel.hasNull())
                    throw new Exception();

                if (pModel.hasNull())
                    throw new Exception();


                response = new PersonResponse(pModel.getPersonID(),
                        pModel.getDescendant(), pModel.getFirstName(),
                        pModel.getLastName(), pModel.getGender(),
                        pModel.getFather(), pModel.getMother(),
                        pModel.getSpouse(), "successful");
                responseArray.add(response);
                response = new PersonResponse();
            }

        }
        catch (Exception e)
        {
            response.setMessage("ERROR");
            responseArray.add(response);
            e.printStackTrace();
        }

        return  responseArray;
    }


}
