package service;

import java.io.FileReader;
import java.io.Reader;
import java.util.UUID;

import database.AuthTokenDAO;
import database.UserDAO;
import handler.Decode;
import jsonTempClass.Locations;
import jsonTempClass.Names;
import model.AuthToken;
import model.User;
import requests.RegisterRequest;
import responses.RegisterResponse;

/**
 * register the person
 */
public class RegisterService
{

    public RegisterService() {}

    String username;

    /**
     * register for the person
     * @param rq
     * @return
     */
    public RegisterResponse Register(RegisterRequest rq)
    {

        String authToken = null;
        String personID = null;
        RegisterResponse response = new RegisterResponse();

        try
        {
            //create authToken for the register user, login for the user
            AuthTokenDAO authDao = new AuthTokenDAO();
            UserDAO uDao = new UserDAO();
            authToken = UUID.randomUUID().toString();
            personID = UUID.randomUUID().toString();


            username = rq.getUserName();
            User userTemp = new User(rq.getUserName(),rq.getPassword(),rq.getEmail(),
                    rq.getFirstName(),rq.getLastName(),rq.getGender(), personID);


            User test = uDao.getUser(rq.getUserName());
            // check if user have null
            if (!test.hasNull())
            {
                response.setMessage("ERROR: This username was registered");
                throw new Exception();
            }

            // cannot have null context
            if(authToken == null || rq.getUserName() == null || personID == null )
            {
                response.setMessage("ERROR: context cannot be null");
                throw new Exception();
            }

            if (rq.getGender().equals("m")||rq.getGender().equals("f")) {

                response = new RegisterResponse(authToken, rq.getUserName(), personID,
                        "successful");
                response.setMessage(null);
                uDao.addUser(userTemp);
                generateFamily();
                //Login
                AuthToken authTemp = new AuthToken(authToken,rq.getUserName());
                authDao.addAuthToken(authTemp);

            }
            else
            {
                response.setMessage("ERROR: please specify your gender");
                throw new Exception();
            }
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
        return  response;

    }

    /**
     * generate family for the register person, call the fill function
     */
    public void generateFamily()
    {
        try {
            Locations location;
            Names femaleNames, maleNames, lastName;
            Decode dc = new Decode();

            Reader locationReader = new FileReader("lib/libs/familymapserver/json/Locations.json");
            location = dc.decodeLocation(locationReader);

            Reader nameReader = new FileReader("lib/libs/familymapserver/json/fnames.json");
            femaleNames = dc.decodeNames(nameReader);

            Reader nameReader2 = new FileReader("lib/libs/familymapserver/json/mnames.json");
            maleNames = dc.decodeNames(nameReader2);

            Reader nameReader3 = new FileReader("lib/libs/familymapserver/json/snames.json");
            lastName = dc.decodeNames(nameReader3);


            Fill fill = new Fill();
            fill.fill(username,4,location,femaleNames,maleNames,lastName);
        }
        catch (Exception e)
        {
            e.printStackTrace();

        }

    }
}
