package handler;

import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;

import java.io.IOException;
import java.io.OutputStream;
import java.net.HttpURLConnection;

import responses.ClearResponse;
import service.Clear;

/**
 *  clear handler, handler the clear call
 */
public class ClearHandler implements HttpHandler
{
    Encode ec;
    ClearResponse rp;
    String response;
    OutputStream resBody;
    @Override

    /**
     * handle the clear call from the server
     */
    public void handle(HttpExchange exchange) throws IOException
    {
        boolean success = false;
        System.out.print("clearHandler");
        try {
            if (exchange.getRequestMethod().toLowerCase().equals("post")) {


                ec = new Encode();
                Clear cl = new Clear();
                rp = cl.clear();


                response = ec.encodeClear(rp);
                resBody = exchange.getResponseBody();
                exchange.sendResponseHeaders(HttpURLConnection.HTTP_OK, 0);

                ec.writeString(response, resBody);

                exchange.getResponseBody().close();
                success = true;

                if (!success) {
                    rp.setMessage("Error");

                    response = ec.encodeClear(rp);
                    resBody = exchange.getResponseBody();
                    exchange.sendResponseHeaders(HttpURLConnection.HTTP_BAD_REQUEST, 0);

                    ec.writeString(response, resBody);

                    exchange.getResponseBody().close();
                }

            }
        } catch (Exception e) {

            rp.setMessage("error");
            response = ec.encodeClear(rp);
            resBody = exchange.getResponseBody();
            exchange.sendResponseHeaders(HttpURLConnection.HTTP_BAD_REQUEST, 0);

            ec.writeString(response, resBody);

            exchange.getResponseBody().close();
        }
        exchange.close();

    }



}
