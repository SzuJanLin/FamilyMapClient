package handler;

import com.google.gson.Gson;
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;

import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.Reader;
import java.net.HttpURLConnection;

import requests.LoginRequest;
import responses.LoginResponse;
import service.LoginService;

/**
 * handle login
 */
public class LoginHandler implements HttpHandler {

    Encode ec;
    LoginResponse rp;
    OutputStream resBody;
    String response;

    /**
     * handle login
     * @param exchange
     * @throws IOException
     */
    public void handle(HttpExchange exchange) throws IOException {
        boolean success = false;
        System.out.print("loginHandler");
        try {
            if (exchange.getRequestMethod().toLowerCase().equals("post")) {
                Gson gson = new Gson();

                ec = new Encode();
                LoginService service = new LoginService();

                Reader in = new InputStreamReader(exchange.getRequestBody());
                LoginRequest request = gson.fromJson(in,LoginRequest.class);


                rp = service.login(request);

                response = ec.encodeLogin(rp);


                resBody = exchange.getResponseBody();
                exchange.sendResponseHeaders(HttpURLConnection.HTTP_OK, 0);

                ec.writeString(response, resBody);

                exchange.getResponseBody().close();
                success = true;

                if (!success) {

                    rp.setMessage("ERROR");
                    response = ec.encodeLogin(rp);
                    resBody = exchange.getResponseBody();
                    exchange.sendResponseHeaders(HttpURLConnection.HTTP_BAD_REQUEST, 0);

                    ec.writeString(response, resBody);

                    exchange.getResponseBody().close();
                }

            }
        } catch (Exception e) {
            rp.setMessage("ERROR");
            response = ec.encodeLogin(rp);
            resBody = exchange.getResponseBody();
            exchange.sendResponseHeaders(HttpURLConnection.HTTP_BAD_REQUEST, 0);

            ec.writeString(response, resBody);

            exchange.getResponseBody().close();
            e.printStackTrace();
        }
        exchange.close();

    }
}


