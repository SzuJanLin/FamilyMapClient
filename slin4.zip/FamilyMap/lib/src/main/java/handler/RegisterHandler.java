package handler;
import com.google.gson.*;
import com.sun.net.httpserver.*;


import java.io.*;
import java.net.*;


import requests.RegisterRequest;
import responses.RegisterResponse;
import service.RegisterService;

/**
 * handle register
 */
public class RegisterHandler implements HttpHandler
{
    public RegisterHandler(){}

    private String username;
    RegisterRequest request;
    Encode ec;
    Gson gson;
    RegisterResponse rp;
    String response;

    /**
     * handle register
     * @param exchange
     * @throws IOException
     */
    public void handle(HttpExchange exchange) throws IOException
    {
    boolean success = false;

        System.out.print("RegisterHandler");
        try {
            if (exchange.getRequestMethod().toLowerCase().equals("post")) {

                gson = new Gson();
                ec = new Encode();

                RegisterService service;
                service = new RegisterService();

                Reader in = new InputStreamReader(exchange.getRequestBody());
                request = gson.fromJson(in,RegisterRequest.class);
                username = request.getUserName();

                rp = service.Register(request);
                response = ec.encodeRegister(rp);


                OutputStream resBody = exchange.getResponseBody();
                exchange.sendResponseHeaders(HttpURLConnection.HTTP_OK, 0);

                ec.writeString(response, resBody);

                exchange.getResponseBody().close();
                success = true;

                if (!success) {
                    rp.setMessage("ERROR");
                    response = ec.encodeRegister(rp);

                    exchange.sendResponseHeaders(HttpURLConnection.HTTP_BAD_REQUEST, 0);
                    ec.writeString(response, resBody);
                    exchange.getResponseBody().close();
                }

            }
        } catch (Exception e) {


            rp.setMessage("ERROR");
            response = ec.encodeRegister(rp);

            OutputStream resBody = exchange.getResponseBody();
            exchange.sendResponseHeaders(HttpURLConnection.HTTP_BAD_REQUEST, 0);
            ec.writeString(response, resBody);
            exchange.getResponseBody().close();
            e.printStackTrace();
        }
        exchange.close();

    }



}




