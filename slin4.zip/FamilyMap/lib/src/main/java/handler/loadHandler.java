package handler;

import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;

import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.Reader;
import java.net.HttpURLConnection;

import requests.LoadRequest;
import responses.LoadResponse;
import service.Load;

/**
 * handle load
 */
public class loadHandler implements HttpHandler
{
    public loadHandler(){}

    String response;
    OutputStream resBody;
    Encode ec;
    LoadResponse rp;

    /**
     * handle load
     * @param exchange
     * @throws IOException
     */
    public void handle(HttpExchange exchange) throws IOException {
        boolean success = false;

        System.out.print("LoadHandler");
        try {
            if (exchange.getRequestMethod().toLowerCase().equals("post"))
            {

                ec = new Encode();
                Decode dc = new Decode();
                Load service = new Load();

                Reader in = new InputStreamReader(exchange.getRequestBody());
                LoadRequest request = dc.decodeLoad(in);
                rp = service.load(request);
                response = ec.encodeLoad(rp);

                resBody = exchange.getResponseBody();
                exchange.sendResponseHeaders(HttpURLConnection.HTTP_OK, 0);
                ec.writeString(response, resBody);

                exchange.getResponseBody().close();
                success = true;

                if (!success) {

                    rp.setMessage("ERROR");
                    response = ec.encodeLoad(rp);
                    resBody = exchange.getResponseBody();
                    exchange.sendResponseHeaders(HttpURLConnection.HTTP_BAD_REQUEST, 0);
                    ec.writeString(response, resBody);


                    exchange.getResponseBody().close();
                }

            }
        } catch (Exception e) {
            rp.setMessage("ERROR");
            response = ec.encodeLoad(rp);
            resBody = exchange.getResponseBody();
            exchange.sendResponseHeaders(HttpURLConnection.HTTP_BAD_REQUEST, 0);
            ec.writeString(response, resBody);


            exchange.getResponseBody().close();
            e.printStackTrace();
        }
        exchange.close();

    }
    }

