package handler;

import com.google.gson.Gson;
import com.sun.net.httpserver.Headers;
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;

import java.io.IOException;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.util.ArrayList;

import database.AuthTokenDAO;
import requests.PersonRequest;
import responses.PersonResponse;
import service.PersonService;

/**
 * handle person
 */
public class PersonHandler implements HttpHandler
{
    /**
     * handle person
     * @param exchange
     * @throws IOException
     */
    @Override
    public void handle(HttpExchange exchange) throws IOException {
        boolean success = false;
        System.out.print("personHandler");
        Gson gson = new Gson();
        Encode ec = new Encode();
        Decode dc = new Decode();
        PersonService service = new PersonService();
        try {
            if (exchange.getRequestMethod().toLowerCase().equals("get")) {


                Headers reqHeaders = exchange.getRequestHeaders();

                if (reqHeaders.containsKey("Authorization"))
                {
                    String authToken = reqHeaders.getFirst("Authorization");

                    AuthTokenDAO authTokenDAO = new AuthTokenDAO();

                    if (authTokenDAO.getUsername(authToken) == null)//assert
                    {
                        throw new Exception();
                    }

                    String theURI = exchange.getRequestURI().toString();
                    String[] personString = theURI.split("/");

                    if(personString.length == 3)
                    {
                       String person_id = personString[2];
                        PersonRequest request = new PersonRequest(authToken,person_id);

                        PersonResponse rp = service.getPerson(request);
                        String response = ec.encodePerson(rp);
                        OutputStream resBody = exchange.getResponseBody();
                        exchange.sendResponseHeaders(HttpURLConnection.HTTP_OK, 0);

                        ec.writeString(response, resBody);

                        exchange.getResponseBody().close();
                        success = true;

                        if (!success) {

                            exchange.sendResponseHeaders(HttpURLConnection.HTTP_BAD_REQUEST, 0);
                            exchange.getResponseBody().close();
                        }
                    }
                    else if (personString.length == 2)
                    {

                        PersonRequest request = new PersonRequest(authToken,"");
                        ArrayList< PersonResponse > rp = service.getPeople(request);
                        String response = ec.encodePeople(rp);

                        OutputStream resBody = exchange.getResponseBody();
                        exchange.sendResponseHeaders(HttpURLConnection.HTTP_OK, 0);

                        ec.writeString(response, resBody);

                        exchange.getResponseBody().close();
                        success = true;

                        if (!success) {

                            PersonResponse rp2 = new PersonResponse();
                            rp2.setMessage("ERROR");
                            String response2 = ec.encodePerson(rp2);

                            OutputStream resBody2 = exchange.getResponseBody();
                            exchange.sendResponseHeaders(HttpURLConnection.HTTP_SERVER_ERROR, 0);
                            ec.writeString(response, resBody);

                            exchange.getResponseBody().close();
                        }
                    }
                }
            }
        } catch (Exception e) {
            PersonResponse rp = new PersonResponse();
            rp.setMessage("ERROR");
            String response = ec.encodePerson(rp);

            OutputStream resBody = exchange.getResponseBody();
            exchange.sendResponseHeaders(HttpURLConnection.HTTP_SERVER_ERROR, 0);
            ec.writeString(response, resBody);

            exchange.getResponseBody().close();
            e.printStackTrace();
        }
        exchange.close();
    }

}
