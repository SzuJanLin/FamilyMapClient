package handler;

import com.google.gson.Gson;
import com.sun.net.httpserver.Headers;
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;

import java.io.IOException;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.util.ArrayList;

import database.AuthTokenDAO;
import requests.EventRequest;
import responses.EventResponse;
import service.EventService;

/**
 * handle the event
 */
public class EventHandler implements HttpHandler
    {
        @Override
        public void handle(HttpExchange exchange) throws IOException {
            boolean success = false;
            Gson gson = new Gson();
            Encode ec = new Encode();
            Decode dc = new Decode();
            System.out.print("eventHandler");
            try {
                if (exchange.getRequestMethod().toLowerCase().equals("get")) {

                    EventService service = new EventService();
                    Headers reqHeaders = exchange.getRequestHeaders();

                    if (reqHeaders.containsKey("Authorization"))
                    {
                        String authToken = reqHeaders.getFirst("Authorization");

                        AuthTokenDAO authTokenDAO = new AuthTokenDAO();

                        String username = authTokenDAO.getUsername(authToken);

                        if (authTokenDAO.getUsername(authToken) == null)
                        {
                            throw new Exception();
                        }


                        String theURI = exchange.getRequestURI().toString();
                        String[] eventString = theURI.split("/");

                        if(eventString.length == 3)
                        {
                            String event_id = eventString[2];

                            EventRequest request = new EventRequest(authToken,event_id);

                            EventResponse rp = service.getEvent(request);
                            String response = ec.encodeEvent(rp);

                            OutputStream resBody = exchange.getResponseBody();
                            exchange.sendResponseHeaders(HttpURLConnection.HTTP_OK, 0);

                            ec.writeString(response, resBody);

                            exchange.getResponseBody().close();
                            success = true;

                            if (!success) {

                                EventResponse rp2 = new EventResponse();
                                rp2.setMessage("ERROR");
                                String response2 = ec.encodeEvent(rp2);

                                OutputStream resBody2 = exchange.getResponseBody();
                                exchange.sendResponseHeaders(HttpURLConnection.HTTP_SERVER_ERROR, 0);
                                ec.writeString(response2, resBody2);

                                exchange.getResponseBody().close();
                            }
                        }
                        else if (eventString.length == 2)
                        {


                            EventRequest request = new EventRequest(authToken,"");

                            ArrayList< EventResponse > rp = service.getEvents(request);

                            String response = ec.encodeEvents(rp);


                            OutputStream resBody = exchange.getResponseBody();
                            exchange.sendResponseHeaders(HttpURLConnection.HTTP_OK, 0);

                            ec.writeString(response, resBody);

                            exchange.getResponseBody().close();
                            success = true;

                            if (!success) {

                                EventResponse rp2 = new EventResponse();
                                rp2.setMessage("ERROR");
                                String response2 = ec.encodeEvent(rp2);

                                OutputStream resBody2 = exchange.getResponseBody();
                                exchange.sendResponseHeaders(HttpURLConnection.HTTP_SERVER_ERROR, 0);
                                ec.writeString(response2, resBody2);

                                exchange.getResponseBody().close();

                            }
                        }
                    }
                }
            } catch (Exception e) {

                EventResponse rp = new EventResponse();
                rp.setMessage("ERROR");
                String response = ec.encodeEvent(rp);

                OutputStream resBody = exchange.getResponseBody();
                exchange.sendResponseHeaders(HttpURLConnection.HTTP_SERVER_ERROR, 0);
                ec.writeString(response, resBody);

                exchange.getResponseBody().close();
                e.printStackTrace();
            }
            exchange.close();

        }





    }


