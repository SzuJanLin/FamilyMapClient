package database;

import junit.framework.TestCase;

import model.Event;

public class EventDAOTest extends TestCase {

    EventDAO test;
    protected void setUp() throws Exception {
        super.setUp();
         test = new EventDAO();
    }


    protected void tearDown() throws Exception
    {
        //test.clear();
    }


    public void testCreateTable() {
    }

    public void testGetEvent() {
        Event output;
       output = test.getEvent("123");
        System.out.println(output.getCity());
    }

    public void testAddEvent() {

        Event testModel = new Event("123","abc",
                "is","so","cool",
                "isn't","it","yeah",5); // Test eventDao add and get fucntions
        test.addEvent(testModel);
        Event output; // duplicated eventID
        output = test.getEvent("123");
        System.out.println(output.getCity());
        System.out.print("stop");
    }

    public void testClear() {
    }

    public void testDelete()
    {
        test.delete("abd"); // succeed
    }
}