package database;

import junit.framework.TestCase;

import model.User;

public class UserDAOTest2 extends TestCase {

    UserDAO testUser;
    public void setUp() throws Exception {
        super.setUp();
        testUser = new UserDAO();

    }

    public void tearDown() throws Exception
    {
       //testUser.clear();

    }

    public void testGetUser()
    {
System.out.println("success");
    }

    public void testAdd()
    {
        User testModel = new User("123","qwe","a@gmail"
                ,"jordan","lin","male","345");
        testUser.addUser(testModel);


        User temp = testUser.getUser("c");
        System.out.print(temp.getPersonID());



    }

    public void testGetUser1() {
        User outcome;
        outcome = testUser.getUser("abc");
        System.out.println(outcome.getPersonID());

    }

    public void testCreateTable() {

    }


    public void testClear()
    {
        testUser.clear();// succeed
        User outcome;
        outcome = testUser.getUser("abc");
        System.out.println(outcome.getPersonID());

    }

    public void testDelete() {
        testUser.delete("1234");
    }// succeed
}