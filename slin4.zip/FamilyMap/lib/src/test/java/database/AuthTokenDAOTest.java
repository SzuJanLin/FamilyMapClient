package database;

import junit.framework.TestCase;

import model.AuthToken;

public class AuthTokenDAOTest extends TestCase {
    AuthTokenDAO test;
    public void setUp() throws Exception {
        super.setUp();
         test = new AuthTokenDAO();
    }

    public void tearDown() throws Exception
    {
    }

    public void testGetAuthToken() {


        String out = test.getAuthToken("qwe");
        System.out.println(out); //there is no username "qwe"
    }

    public void testAddAuthToken()
    {
        AuthToken auth = new AuthToken("abd","123");
        test.addAuthToken(auth);
    }

    public void testClear()
    {
        test.clear(); // succeed
    }
}