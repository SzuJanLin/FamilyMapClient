package database;

import junit.framework.TestCase;

import java.util.ArrayList;

import model.Person;

public class PersonDAOTest extends TestCase {

    PersonDAO PersonTest;
    public void setUp() throws Exception {
        super.setUp();
        PersonTest = new PersonDAO();
    }

    public void tearDown() throws Exception
    {
       PersonTest.clear();
    }

    public void testGetPerson()
    {
        PersonTest.clear();

        Person yeah = PersonTest.getPerson("157");
        System.out.println(yeah.getFather());


    }

    public void testAddPerson()
    {
//        Person Me = new Person("157","abc","Jordan",
//                "Lin2","M","jin sheng",
//                "xiao juan","prettiest");
//        PersonTest.addPerson(Me);

        Person yeah; // get person succeed
       yeah = PersonTest.getPerson("157");
        System.out.println(yeah.getFather());

    }




}