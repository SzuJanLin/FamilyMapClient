package service;

import junit.framework.TestCase;

public class ClearTest extends TestCase {

    Clear clear;
    public void setUp() throws Exception {
        super.setUp();
        clear = new Clear();
    }

    public void tearDown() throws Exception {
    }

    public void testClear()
    {
        // clear function with out having initialized database
        clear.clear();
    }
}