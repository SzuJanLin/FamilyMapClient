package service;

import junit.framework.TestCase;

import java.util.ArrayList;

import requests.EventRequest;
import responses.EventResponse;

public class EventServiceTest extends TestCase {

    EventService es;
    public void setUp() throws Exception {
        super.setUp();
        es = new EventService();
    }

    public void tearDown() throws Exception {
    }

    public void testGetEvents()
    { //wrong authToken and id
        EventRequest rq = new EventRequest("plod","1");
        EventResponse rp = es.getEvent(rq);
        ArrayList<EventResponse> rps =  es.getEvents(rq);
        System.out.print("stop");
    }
}