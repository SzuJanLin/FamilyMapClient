package service;

import junit.framework.TestCase;

import java.io.FileReader;
import java.io.Reader;
import java.util.ArrayList;

import database.EventDAO;
import database.PersonDAO;
import database.UserDAO;
import handler.Decode;
import handler.Encode;
import jsonTempClass.Names;
import jsonTempClass.Locations;
import responses.FillResponse;

public class FillTest extends TestCase {
    private int generationCount;
    private UserDAO userDAO;
    private PersonDAO personDAO;
    private EventDAO eventDAO;
    private Decode dc;
    private Encode ec;
    int personCounter;
    int eventCounter;
    String username;
    int generation;
    Locations Locations;
    ArrayList<String> eventType;

    Names fnames;
    Names mnames;
    Names snames;
    private Locations location;
    private Names maleNames, femaleNames, lastName;
    public void setUp() throws Exception
    {
        super.setUp();

        userDAO = new UserDAO();
        personDAO = new PersonDAO();
        eventDAO = new EventDAO();
        dc = new Decode();

        Reader locationReader = new FileReader("lib/libs/familymapserver/json/Locations.json");
        location = dc.decodeLocation(locationReader);

        Reader nameReader = new FileReader("lib/libs/familymapserver/json/fnames.json");
        femaleNames = dc.decodeNames(nameReader);

        Reader nameReader2 = new FileReader("lib/libs/familymapserver/json/mnames.json");
        maleNames = dc.decodeNames(nameReader2);

        Reader nameReader3 = new FileReader("lib/libs/familymapserver/json/snames.json");
        lastName = dc.decodeNames(nameReader3);

    }

    public void tearDown() throws Exception
    {
    }

    public void testFill()
    {
        Fill service = new Fill();
        FillResponse rp = service.fill("123",4,
                location,femaleNames,maleNames,lastName); // succeed
        System.out.print("stop");
    }
}