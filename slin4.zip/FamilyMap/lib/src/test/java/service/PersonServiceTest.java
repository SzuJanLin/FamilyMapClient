package service;

import junit.framework.TestCase;

import java.lang.reflect.Array;
import java.util.ArrayList;

import requests.PersonRequest;
import responses.PersonResponse;

public class PersonServiceTest extends TestCase {

    PersonService ps;
    public void setUp() throws Exception {
        super.setUp();
        ps = new PersonService();
    }

    public void tearDown() throws Exception
    {

    }

    public void testGetPerson()
    {
        PersonResponse rp;
        PersonRequest rq = new PersonRequest("abd","123");
        rp = ps.getPerson(rq);
        System.out.print("stop");
    } // wrong authToken
}