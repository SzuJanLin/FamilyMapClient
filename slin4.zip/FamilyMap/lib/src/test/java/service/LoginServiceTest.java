package service;

import junit.framework.TestCase;

import requests.LoginRequest;
import responses.LoginResponse;

public class LoginServiceTest extends TestCase {

    LoginService test;
    public void setUp() throws Exception
    {
        super.setUp();

        test = new LoginService();
    }

    public void tearDown() throws Exception
    {
    }

    public void testLogin()
    {
        LoginRequest rq = new LoginRequest("123","123");
        LoginResponse rp;
        rp = test.login(rq);// succeed

        System.out.print("stop");

    }
}