package service;

import junit.framework.TestCase;

import requests.RegisterRequest;

public class RegisterServiceTest extends TestCase {

    RegisterService rs;
    public void setUp() throws Exception
    {
        super.setUp();
        rs = new RegisterService();
    }

    public void tearDown() throws Exception {
    }

    public void testRegister()
    {
        RegisterRequest rq = new RegisterRequest("i",
                "am","jordan",
                "lin","siran","m"); //succeed
        rs.Register(rq);
    }
}