package service;

import junit.framework.TestCase;

import model.Event;
import model.Person;
import model.User;
import requests.LoadRequest;
import responses.LoadResponse;

public class LoadTest extends TestCase {


    Load load;
    public void setUp() throws Exception {
        super.setUp();
        load = new Load();
    }

    public void tearDown() throws Exception
    {
    }

    public void testLoad()
    {
        User temp = new User("123","234","345",
                "aji","eij","djij","eji");

        User temp2 = new User("125","234","345",
                "aji","eij","djij","ejl");


        Event testModel = new Event("6","abc",
                "is","so","cool",
                "isn't","it","yeah",5);

        Person Me = new Person("3","abc","Jordan",
                "Lin2","M","jin sheng",
                "xiao juan","prettiest");

        LoadRequest rq = new LoadRequest();
        rq.getEvents().add(testModel);
        rq.getUsers().add(temp);

        LoadResponse rp = load.load(rq);

        System.out.print("stop\n");


    }
}