import junit.framework.TestCase;

public class ServerTest extends TestCase {

    Server server;
    public void setUp() throws Exception {
        super.setUp();
        server = new Server();
    }

    public void tearDown() throws Exception {
    }


    public void testMain()
    {
        String[] args = {"8080"};
        server.main(args);

    }
}